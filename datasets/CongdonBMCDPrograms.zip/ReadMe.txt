These programs were developed with WINBUGS1.4. Occasionally programs that don't work in 
WINBUGS1.4 do work in WINBUGS1.3, and this will be explicitly mentioned. 

Please note important changes in syntax between versions, 
especially how matrix inversion is coded:
Winbugs 1.4 
A[1:m,1:m] <- inverse(B[,])
Winbugs 1.3
for (j in 1:m) { for (j in 1:m) {A[j,k] <- inverse(B[,],j,k)}}

Also it is no longer permissible to write univariate priors in compact form:
So instead of
theta[1:p] ~ dnorm(0,0.001)
one has to explicitly write
for (j in 1:p) {theta[j] ~ dnorm(0,0.001)}
otherwise a multivariate node message will be generated.

Sometimes a program is subject to occasional overflow or cannot sample messages but 
the iteration sequence can be restarted by pressing update again.


