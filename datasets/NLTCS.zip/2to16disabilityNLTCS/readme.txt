The directory contains: 

2to16disabilityNLTCS.txt -- data file, 
2to16table-description.pdf � description of the data, 
2to16table-briefdescription.txt � brief description of the data, 
redistribution.pdf � redistribution statement.  







