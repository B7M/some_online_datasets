This data is used in the following book:

Aldrich, J. and Forrest, N. (1984) Linear Probability, Logit and Probit Models.
Series: Quantitative Applications in The Social Sciences. A Sage University Paper.

You have it in different formats, Stata (.dta), Text (.txt) and Excel (.xls)

Any questions or feedback, feel free to contact me:
hromerov01@yahoo.com